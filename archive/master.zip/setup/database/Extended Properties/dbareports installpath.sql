EXEC sp_addextendedproperty N'dbareports installpath', N'', NULL, NULL, NULL, NULL, NULL, NULL
GO

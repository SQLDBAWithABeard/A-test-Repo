CREATE TABLE [dbo].[NotEntered]
(
[date] [datetime] NOT NULL,
[Notentered] [int] NOT NULL
) ON [PRIMARY]
GO
